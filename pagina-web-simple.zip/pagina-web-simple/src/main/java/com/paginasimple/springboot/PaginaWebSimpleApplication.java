package com.paginasimple.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaWebSimpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaWebSimpleApplication.class, args);
	}

}
