package com.paginasimple.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaWebSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
